import React from 'react';
import { Target, CheckCircle, TrendingUp, Users, ArrowRight, Star, ShoppingCart, ListTodo, Trophy, BarChart as FlowChart, Crown, Coins } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      {/* Header/Navigation */}
      <nav className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Target className="h-8 w-8 text-indigo-400" />
            <span className="text-2xl font-bold">GoalGame</span>
          </div>
          <div className="hidden md:flex space-x-6">
            <a href="#features" className="text-gray-300 hover:text-indigo-400">Features</a>
            <a href="#showcase" className="text-gray-300 hover:text-indigo-400">Showcase</a>
            <a href="#testimonials" className="text-gray-300 hover:text-indigo-400">Testimonials</a>
          </div>
          <div className="flex space-x-4">
            <button className="px-4 py-2 text-gray-300 hover:text-indigo-400">Log in</button>
            <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
              Sign up
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-6 py-16 text-center">
        <h1 className="text-5xl font-bold mb-6">
          Transform Your Goals into an Epic Journey
        </h1>
        <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          More than just a to-do list - GoalGame turns your daily tasks, shopping, and goals into an exciting adventure with rewards, achievements, and friendly competition.
        </p>
        <button className="px-8 py-3 bg-indigo-600 text-white rounded-lg text-lg hover:bg-indigo-700 flex items-center space-x-2 mx-auto">
          <span>Start Your Journey</span>
          <ArrowRight className="h-5 w-5" />
        </button>
      </section>

      {/* Core Features Section */}
      <section id="features" className="bg-gray-900 py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose GoalGame?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
              <CheckCircle className="h-12 w-12 text-indigo-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Track Progress</h3>
              <p className="text-gray-300">Visualize your journey with interactive flow charts and progress tracking.</p>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
              <Trophy className="h-12 w-12 text-indigo-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Compete & Win</h3>
              <p className="text-gray-300">Challenge friends and climb the global leaderboard.</p>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
              <Coins className="h-12 w-12 text-indigo-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Earn Rewards</h3>
              <p className="text-gray-300">Collect coins to unlock exclusive avatars and customizations.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Showcase Section */}
      <section id="showcase" className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">Everything You Need to Succeed</h2>
          
          {/* Streak Feature */}
          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-8 rounded-2xl shadow-lg border border-gray-700">
              <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
                <Star className="h-8 w-8 text-indigo-400 mb-4" />
                <h3 className="text-2xl font-bold mb-4">Build Your Streak</h3>
                <ul className="space-y-3 text-gray-300">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Daily goal tracking</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Streak multipliers</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Bonus rewards for consistency</span>
                  </li>
                </ul>
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-4">Maintain Your Momentum</h3>
              <p className="text-gray-300 mb-6">
                Stay motivated with daily streaks. Complete your goals consistently to earn multipliers and unlock special achievements. The longer your streak, the bigger your rewards!
              </p>
            </div>
          </div>

          {/* Smart Lists Feature */}
          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-8 rounded-2xl shadow-lg border border-gray-700">
              <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
                <ShoppingCart className="h-8 w-8 text-indigo-400 mb-4" />
                <h3 className="text-2xl font-bold mb-4">Smart Lists</h3>
                <ul className="space-y-3 text-gray-300">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Intelligent grocery categorization</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Recurring items prediction</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Share lists with family</span>
                  </li>
                </ul>
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-4">Intelligent List Management</h3>
              <p className="text-gray-300 mb-6">
                From grocery lists to daily tasks, our smart categorization and prediction system makes organization effortless. Share lists with family and friends for seamless collaboration.
              </p>
            </div>
          </div>

          {/* Goal Tracking Feature */}
          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-8 rounded-2xl shadow-lg border border-gray-700">
              <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
                <FlowChart className="h-8 w-8 text-indigo-400 mb-4" />
                <h3 className="text-2xl font-bold mb-4">Flow Charts</h3>
                <ul className="space-y-3 text-gray-300">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Interactive goal mapping</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Progress visualization</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Milestone tracking</span>
                  </li>
                </ul>
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-4">Visual Goal Tracking</h3>
              <p className="text-gray-300 mb-6">
                Transform your goals into interactive flow charts. Break down big objectives into manageable steps, track dependencies, and celebrate progress at every milestone.
              </p>
            </div>
          </div>

          {/* Social Features */}
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-8 rounded-2xl shadow-lg border border-gray-700">
              <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
                <Crown className="h-8 w-8 text-indigo-400 mb-4" />
                <h3 className="text-2xl font-bold mb-4">Global Achievement System</h3>
                <ul className="space-y-3 text-gray-300">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Points for every completed task</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Global ranking system</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span>Weekly challenges</span>
                  </li>
                </ul>
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-4">Track Global Progress</h3>
              <p className="text-gray-300 mb-6">
                Earn points for every completed task and see how you rank globally. Join weekly challenges, climb the leaderboards, and showcase your achievements to the world.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="bg-gray-900 py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">What Our Users Say</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
              <div className="flex items-center mb-4">
                <img
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&h=100"
                  alt="User"
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-semibold">Sarah Johnson</h4>
                  <p className="text-gray-400">Product Manager</p>
                </div>
              </div>
              <p className="text-gray-300">"The flow chart feature helps me break down complex projects into manageable steps. The gamification aspect keeps me motivated every day!"</p>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
              <div className="flex items-center mb-4">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&h=100"
                  alt="User"
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-semibold">Michael Chen</h4>
                  <p className="text-gray-400">Software Developer</p>
                </div>
              </div>
              <p className="text-gray-300">"Competing with friends on the leaderboard makes task completion exciting. The smart grocery list feature saves me time every week!"</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-8 border-t border-gray-800">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Target className="h-6 w-6 text-indigo-400" />
              <span className="text-xl font-bold">GoalGame</span>
            </div>
            <p className="text-gray-400">© 2024 GoalGame. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;